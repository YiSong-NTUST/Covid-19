﻿namespace Spectrum_Test
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea11 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend11 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series11 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea10 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend10 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend9 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Command_page = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnROI = new System.Windows.Forms.Button();
            this.btnELC1000 = new System.Windows.Forms.Button();
            this.btnELC = new System.Windows.Forms.Button();
            this.btnGNV128 = new System.Windows.Forms.Button();
            this.btnGNV = new System.Windows.Forms.Button();
            this.btnAGN2X = new System.Windows.Forms.Button();
            this.btnAGN1X = new System.Windows.Forms.Button();
            this.btnAGN = new System.Windows.Forms.Button();
            this.btnCommand = new System.Windows.Forms.Button();
            this.txtCommand = new System.Windows.Forms.TextBox();
            this.btnCAL = new System.Windows.Forms.Button();
            this.BLE_test_page = new System.Windows.Forms.TabPage();
            this.Motor_test_page = new System.Windows.Forms.TabPage();
            this.btnMotor_Test = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txt_motor_test_round = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.LED_test_page = new System.Windows.Forms.TabPage();
            this.B_LED_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label59 = new System.Windows.Forms.Label();
            this.LED_test_roi_lc_txt = new System.Windows.Forms.TextBox();
            this.LED_test_RUN_cycle_txt = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.LED_test_roi_vo_txt = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.LED_test_roi_hc_txt = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.LED_test_roi_ho_txt = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.LED_test_I_thr_txt = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.LED_test_I_max_txt = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.LED_test_EXP_max_txt = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.LED_test_EXP_initial_txt = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.LED_test_AG_txt = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.LED_test_DG_txt = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.LED_test_T2_txt = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.LED_test_T1_txt = new System.Windows.Forms.TextBox();
            this.LED_test_wl_txt = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.LED_test_a3_txt = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.LED_test_a2_txt = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.LED_test_a1_txt = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.LED_test_a0_txt = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.LED_test_interval_time_txt = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.LED_test_total_times_txt = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.A_LED_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnLED_Test_Stop = new System.Windows.Forms.Button();
            this.btnLED_Test_Start = new System.Windows.Forms.Button();
            this.SP_test_page = new System.Windows.Forms.TabPage();
            this.line_num_txt = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.reflect_sp_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.distance_sp_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.point_sp_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dark_sp_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SP_point_distance_txt = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.SP_test_roi_lc_txt = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.SP_test_roi_vo_txt = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.SP_test_roi_hc_txt = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.SP_test_roi_ho_txt = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.SP_test_CAL_RUN_cycle_txt = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.SP_test_step_distance_txt = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.SP_test_x1_txt = new System.Windows.Forms.TextBox();
            this.SP_test_Xsc_txt = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.SP_test_I_thr_txt = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.SP_test_I_max_txt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.SP_test_EXP_max_txt = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.SP_test_EXP_initial_txt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.SP_test_AG_txt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.SP_test_DG_txt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.SP_test_T2_txt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.SP_test_T1_txt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.SP_test_Xts_txt = new System.Windows.Forms.TextBox();
            this.SP_test_wl_txt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.SP_test_a3_txt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SP_test_a2_txt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SP_test_a1_txt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SP_test_a0_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SP_test_point_distance_steps_txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SP_test_total_point_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SP_test_xAS_txt = new System.Windows.Forms.TextBox();
            this.btnSpectrum_Test_Stop = new System.Windows.Forms.Button();
            this.btnSpectrum_Test_Start = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.cboPort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            this.label20 = new System.Windows.Forms.Label();
            this.status_lb = new System.Windows.Forms.Label();
            this.txtAPI = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.btnApi = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart5 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.baseline_start_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.baseline_end_txt = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.Command_page.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.Motor_test_page.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.LED_test_page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.B_LED_chart)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.A_LED_chart)).BeginInit();
            this.SP_test_page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reflect_sp_chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.distance_sp_chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.point_sp_chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dark_sp_chart)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Command_page);
            this.tabControl1.Controls.Add(this.BLE_test_page);
            this.tabControl1.Controls.Add(this.Motor_test_page);
            this.tabControl1.Controls.Add(this.LED_test_page);
            this.tabControl1.Controls.Add(this.SP_test_page);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(3, 46);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1049, 572);
            this.tabControl1.TabIndex = 0;
            // 
            // Command_page
            // 
            this.Command_page.Controls.Add(this.tabControl2);
            this.Command_page.Controls.Add(this.button2);
            this.Command_page.Controls.Add(this.button3);
            this.Command_page.Controls.Add(this.button1);
            this.Command_page.Controls.Add(this.btnROI);
            this.Command_page.Controls.Add(this.btnELC1000);
            this.Command_page.Controls.Add(this.btnELC);
            this.Command_page.Controls.Add(this.btnGNV128);
            this.Command_page.Controls.Add(this.btnGNV);
            this.Command_page.Controls.Add(this.btnAGN2X);
            this.Command_page.Controls.Add(this.btnAGN1X);
            this.Command_page.Controls.Add(this.btnAGN);
            this.Command_page.Controls.Add(this.btnCommand);
            this.Command_page.Controls.Add(this.txtCommand);
            this.Command_page.Controls.Add(this.btnCAL);
            this.Command_page.Location = new System.Drawing.Point(4, 22);
            this.Command_page.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Command_page.Name = "Command_page";
            this.Command_page.Size = new System.Drawing.Size(1041, 546);
            this.Command_page.TabIndex = 4;
            this.Command_page.Text = "Command測試";
            this.Command_page.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Location = new System.Drawing.Point(463, 1);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(577, 545);
            this.tabControl2.TabIndex = 29;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.txtLog);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage3.Size = new System.Drawing.Size(569, 519);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Log";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txtLog
            // 
            this.txtLog.BackColor = System.Drawing.Color.Black;
            this.txtLog.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLog.ForeColor = System.Drawing.Color.White;
            this.txtLog.Location = new System.Drawing.Point(0, 0);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(573, 519);
            this.txtLog.TabIndex = 12;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.checkBox4);
            this.tabPage4.Controls.Add(this.chart1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage4.Size = new System.Drawing.Size(569, 519);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "光譜圖";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(5, 4);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(48, 16);
            this.checkBox4.TabIndex = 16;
            this.checkBox4.Text = "動態";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(0, 0);
            this.chart1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(569, 519);
            this.chart1.TabIndex = 15;
            this.chart1.Text = "chart1";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(88, 320);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 18);
            this.button2.TabIndex = 28;
            this.button2.Text = "SWL1";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(27, 320);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(56, 18);
            this.button3.TabIndex = 27;
            this.button3.Text = "SWL0";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(88, 297);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 18);
            this.button1.TabIndex = 26;
            this.button1.Text = "btnROI488";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnROI
            // 
            this.btnROI.Location = new System.Drawing.Point(27, 297);
            this.btnROI.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnROI.Name = "btnROI";
            this.btnROI.Size = new System.Drawing.Size(56, 18);
            this.btnROI.TabIndex = 25;
            this.btnROI.Text = "ROI?";
            this.btnROI.UseVisualStyleBackColor = true;
            this.btnROI.Click += new System.EventHandler(this.btnROI_Click);
            // 
            // btnELC1000
            // 
            this.btnELC1000.Location = new System.Drawing.Point(88, 274);
            this.btnELC1000.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnELC1000.Name = "btnELC1000";
            this.btnELC1000.Size = new System.Drawing.Size(56, 18);
            this.btnELC1000.TabIndex = 24;
            this.btnELC1000.Text = "ELC1000";
            this.btnELC1000.UseVisualStyleBackColor = true;
            this.btnELC1000.Click += new System.EventHandler(this.btnELC1000_Click);
            // 
            // btnELC
            // 
            this.btnELC.Location = new System.Drawing.Point(27, 274);
            this.btnELC.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnELC.Name = "btnELC";
            this.btnELC.Size = new System.Drawing.Size(56, 18);
            this.btnELC.TabIndex = 23;
            this.btnELC.Text = "ELC?";
            this.btnELC.UseVisualStyleBackColor = true;
            this.btnELC.Click += new System.EventHandler(this.btnELC_Click);
            // 
            // btnGNV128
            // 
            this.btnGNV128.Location = new System.Drawing.Point(88, 250);
            this.btnGNV128.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGNV128.Name = "btnGNV128";
            this.btnGNV128.Size = new System.Drawing.Size(56, 18);
            this.btnGNV128.TabIndex = 22;
            this.btnGNV128.Text = "GNV128";
            this.btnGNV128.UseVisualStyleBackColor = true;
            this.btnGNV128.Click += new System.EventHandler(this.btnGNV128_Click);
            // 
            // btnGNV
            // 
            this.btnGNV.Location = new System.Drawing.Point(27, 250);
            this.btnGNV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGNV.Name = "btnGNV";
            this.btnGNV.Size = new System.Drawing.Size(56, 18);
            this.btnGNV.TabIndex = 21;
            this.btnGNV.Text = "GNV?";
            this.btnGNV.UseVisualStyleBackColor = true;
            this.btnGNV.Click += new System.EventHandler(this.btnGNV_Click);
            // 
            // btnAGN2X
            // 
            this.btnAGN2X.Location = new System.Drawing.Point(148, 227);
            this.btnAGN2X.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAGN2X.Name = "btnAGN2X";
            this.btnAGN2X.Size = new System.Drawing.Size(56, 18);
            this.btnAGN2X.TabIndex = 20;
            this.btnAGN2X.Text = "AGN2X";
            this.btnAGN2X.UseVisualStyleBackColor = true;
            this.btnAGN2X.Click += new System.EventHandler(this.btnAGN2X_Click);
            // 
            // btnAGN1X
            // 
            this.btnAGN1X.Location = new System.Drawing.Point(88, 227);
            this.btnAGN1X.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAGN1X.Name = "btnAGN1X";
            this.btnAGN1X.Size = new System.Drawing.Size(56, 18);
            this.btnAGN1X.TabIndex = 19;
            this.btnAGN1X.Text = "AGN1X";
            this.btnAGN1X.UseVisualStyleBackColor = true;
            this.btnAGN1X.Click += new System.EventHandler(this.btnAGN1X_Click);
            // 
            // btnAGN
            // 
            this.btnAGN.Location = new System.Drawing.Point(27, 227);
            this.btnAGN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAGN.Name = "btnAGN";
            this.btnAGN.Size = new System.Drawing.Size(56, 18);
            this.btnAGN.TabIndex = 18;
            this.btnAGN.Text = "AGN?";
            this.btnAGN.UseVisualStyleBackColor = true;
            this.btnAGN.Click += new System.EventHandler(this.btnAGN_Click);
            // 
            // btnCommand
            // 
            this.btnCommand.Location = new System.Drawing.Point(215, 178);
            this.btnCommand.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCommand.Name = "btnCommand";
            this.btnCommand.Size = new System.Drawing.Size(62, 18);
            this.btnCommand.TabIndex = 17;
            this.btnCommand.Text = "Command";
            this.btnCommand.UseVisualStyleBackColor = true;
            this.btnCommand.Click += new System.EventHandler(this.btnCommand_Click);
            // 
            // txtCommand
            // 
            this.txtCommand.Location = new System.Drawing.Point(27, 178);
            this.txtCommand.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtCommand.Multiline = true;
            this.txtCommand.Name = "txtCommand";
            this.txtCommand.Size = new System.Drawing.Size(185, 19);
            this.txtCommand.TabIndex = 16;
            // 
            // btnCAL
            // 
            this.btnCAL.Location = new System.Drawing.Point(27, 343);
            this.btnCAL.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCAL.Name = "btnCAL";
            this.btnCAL.Size = new System.Drawing.Size(56, 18);
            this.btnCAL.TabIndex = 15;
            this.btnCAL.Text = "CAL";
            this.btnCAL.UseVisualStyleBackColor = true;
            this.btnCAL.Click += new System.EventHandler(this.btnCAL_Click);
            // 
            // BLE_test_page
            // 
            this.BLE_test_page.Location = new System.Drawing.Point(4, 22);
            this.BLE_test_page.Name = "BLE_test_page";
            this.BLE_test_page.Size = new System.Drawing.Size(1041, 546);
            this.BLE_test_page.TabIndex = 9;
            this.BLE_test_page.Text = "藍芽測試";
            this.BLE_test_page.UseVisualStyleBackColor = true;
            // 
            // Motor_test_page
            // 
            this.Motor_test_page.Controls.Add(this.btnMotor_Test);
            this.Motor_test_page.Controls.Add(this.groupBox5);
            this.Motor_test_page.Location = new System.Drawing.Point(4, 22);
            this.Motor_test_page.Name = "Motor_test_page";
            this.Motor_test_page.Size = new System.Drawing.Size(1041, 546);
            this.Motor_test_page.TabIndex = 8;
            this.Motor_test_page.Text = "馬達測試";
            this.Motor_test_page.UseVisualStyleBackColor = true;
            // 
            // btnMotor_Test
            // 
            this.btnMotor_Test.Location = new System.Drawing.Point(412, 117);
            this.btnMotor_Test.Name = "btnMotor_Test";
            this.btnMotor_Test.Size = new System.Drawing.Size(75, 23);
            this.btnMotor_Test.TabIndex = 8;
            this.btnMotor_Test.Text = "測試";
            this.btnMotor_Test.UseVisualStyleBackColor = true;
            this.btnMotor_Test.Click += new System.EventHandler(this.btnMotor_Test_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txt_motor_test_round);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.textBox10);
            this.groupBox5.Location = new System.Drawing.Point(7, 15);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(480, 85);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "馬達設定";
            // 
            // txt_motor_test_round
            // 
            this.txt_motor_test_round.Location = new System.Drawing.Point(137, 49);
            this.txt_motor_test_round.Name = "txt_motor_test_round";
            this.txt_motor_test_round.Size = new System.Drawing.Size(111, 22);
            this.txt_motor_test_round.TabIndex = 23;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(12, 52);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(101, 12);
            this.label23.TabIndex = 22;
            this.label23.Text = "馬達測試來回趟數";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(256, 24);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(17, 12);
            this.label24.TabIndex = 11;
            this.label24.Text = "步";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(12, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(119, 12);
            this.label25.TabIndex = 9;
            this.label25.Text = "步進馬達定義  1mm = ";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(137, 21);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(111, 22);
            this.textBox10.TabIndex = 8;
            // 
            // LED_test_page
            // 
            this.LED_test_page.Controls.Add(this.B_LED_chart);
            this.LED_test_page.Controls.Add(this.groupBox2);
            this.LED_test_page.Controls.Add(this.A_LED_chart);
            this.LED_test_page.Controls.Add(this.btnLED_Test_Stop);
            this.LED_test_page.Controls.Add(this.btnLED_Test_Start);
            this.LED_test_page.Location = new System.Drawing.Point(4, 22);
            this.LED_test_page.Name = "LED_test_page";
            this.LED_test_page.Size = new System.Drawing.Size(1041, 546);
            this.LED_test_page.TabIndex = 7;
            this.LED_test_page.Text = "LED穩定性測試";
            this.LED_test_page.UseVisualStyleBackColor = true;
            // 
            // B_LED_chart
            // 
            chartArea2.Name = "ChartArea1";
            this.B_LED_chart.ChartAreas.Add(chartArea2);
            legend2.Enabled = false;
            legend2.Name = "Legend1";
            this.B_LED_chart.Legends.Add(legend2);
            this.B_LED_chart.Location = new System.Drawing.Point(497, 275);
            this.B_LED_chart.Name = "B_LED_chart";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.IsVisibleInLegend = false;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.B_LED_chart.Series.Add(series2);
            this.B_LED_chart.Size = new System.Drawing.Size(541, 265);
            this.B_LED_chart.TabIndex = 54;
            this.B_LED_chart.Text = "B_LED_chart";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label59);
            this.groupBox2.Controls.Add(this.LED_test_roi_lc_txt);
            this.groupBox2.Controls.Add(this.LED_test_RUN_cycle_txt);
            this.groupBox2.Controls.Add(this.label60);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.LED_test_roi_vo_txt);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.label61);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.LED_test_roi_hc_txt);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.label62);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.LED_test_roi_ho_txt);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.label63);
            this.groupBox2.Controls.Add(this.LED_test_I_thr_txt);
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.LED_test_I_max_txt);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.LED_test_EXP_max_txt);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.LED_test_EXP_initial_txt);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.LED_test_AG_txt);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.LED_test_DG_txt);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.LED_test_T2_txt);
            this.groupBox2.Controls.Add(this.label49);
            this.groupBox2.Controls.Add(this.LED_test_T1_txt);
            this.groupBox2.Controls.Add(this.LED_test_wl_txt);
            this.groupBox2.Controls.Add(this.label51);
            this.groupBox2.Controls.Add(this.LED_test_a3_txt);
            this.groupBox2.Controls.Add(this.label52);
            this.groupBox2.Controls.Add(this.LED_test_a2_txt);
            this.groupBox2.Controls.Add(this.label53);
            this.groupBox2.Controls.Add(this.LED_test_a1_txt);
            this.groupBox2.Controls.Add(this.label54);
            this.groupBox2.Controls.Add(this.LED_test_a0_txt);
            this.groupBox2.Controls.Add(this.label55);
            this.groupBox2.Controls.Add(this.LED_test_interval_time_txt);
            this.groupBox2.Controls.Add(this.label56);
            this.groupBox2.Controls.Add(this.LED_test_total_times_txt);
            this.groupBox2.Controls.Add(this.label57);
            this.groupBox2.Location = new System.Drawing.Point(7, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(481, 386);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "LED測試";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label59.Location = new System.Drawing.Point(15, 259);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(28, 12);
            this.label59.TabIndex = 111;
            this.label59.Text = "ROI";
            // 
            // LED_test_roi_lc_txt
            // 
            this.LED_test_roi_lc_txt.Location = new System.Drawing.Point(362, 282);
            this.LED_test_roi_lc_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_roi_lc_txt.Name = "LED_test_roi_lc_txt";
            this.LED_test_roi_lc_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_roi_lc_txt.TabIndex = 110;
            // 
            // LED_test_RUN_cycle_txt
            // 
            this.LED_test_RUN_cycle_txt.Location = new System.Drawing.Point(301, 344);
            this.LED_test_RUN_cycle_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_RUN_cycle_txt.Name = "LED_test_RUN_cycle_txt";
            this.LED_test_RUN_cycle_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_RUN_cycle_txt.TabIndex = 91;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(326, 285);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(32, 12);
            this.label60.TabIndex = 109;
            this.label60.Text = "roi_lc";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(244, 347);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 12);
            this.label34.TabIndex = 90;
            this.label34.Text = "測試次數";
            // 
            // LED_test_roi_vo_txt
            // 
            this.LED_test_roi_vo_txt.Location = new System.Drawing.Point(264, 282);
            this.LED_test_roi_vo_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_roi_vo_txt.Name = "LED_test_roi_vo_txt";
            this.LED_test_roi_vo_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_roi_vo_txt.TabIndex = 108;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label35.Location = new System.Drawing.Point(14, 321);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(57, 12);
            this.label35.TabIndex = 89;
            this.label35.Text = "檢測參數";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(224, 285);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(36, 12);
            this.label61.TabIndex = 107;
            this.label61.Text = "roi_vo";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label36.Location = new System.Drawing.Point(14, 188);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(83, 12);
            this.label36.TabIndex = 88;
            this.label36.Text = "波長校正係數";
            // 
            // LED_test_roi_hc_txt
            // 
            this.LED_test_roi_hc_txt.Location = new System.Drawing.Point(163, 282);
            this.LED_test_roi_hc_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_roi_hc_txt.Name = "LED_test_roi_hc_txt";
            this.LED_test_roi_hc_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_roi_hc_txt.TabIndex = 106;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label38.Location = new System.Drawing.Point(14, 93);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(102, 12);
            this.label38.TabIndex = 86;
            this.label38.Text = "Auto-scaling參數";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(123, 285);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(35, 12);
            this.label62.TabIndex = 105;
            this.label62.Text = "roi_hc";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label39.Location = new System.Drawing.Point(14, 29);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(108, 12);
            this.label39.TabIndex = 85;
            this.label39.Text = "LED等待時間參數";
            // 
            // LED_test_roi_ho_txt
            // 
            this.LED_test_roi_ho_txt.Location = new System.Drawing.Point(62, 282);
            this.LED_test_roi_ho_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_roi_ho_txt.Name = "LED_test_roi_ho_txt";
            this.LED_test_roi_ho_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_roi_ho_txt.TabIndex = 104;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(260, 148);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(25, 12);
            this.label42.TabIndex = 80;
            this.label42.Text = "I thr";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(21, 285);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(36, 12);
            this.label63.TabIndex = 103;
            this.label63.Text = "roi_ho";
            // 
            // LED_test_I_thr_txt
            // 
            this.LED_test_I_thr_txt.Location = new System.Drawing.Point(288, 145);
            this.LED_test_I_thr_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_I_thr_txt.Name = "LED_test_I_thr_txt";
            this.LED_test_I_thr_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_I_thr_txt.TabIndex = 79;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(254, 120);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(32, 12);
            this.label43.TabIndex = 78;
            this.label43.Text = "I max";
            // 
            // LED_test_I_max_txt
            // 
            this.LED_test_I_max_txt.Location = new System.Drawing.Point(288, 117);
            this.LED_test_I_max_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_I_max_txt.Name = "LED_test_I_max_txt";
            this.LED_test_I_max_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_I_max_txt.TabIndex = 77;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(123, 148);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(49, 12);
            this.label44.TabIndex = 76;
            this.label44.Text = "EXP max";
            // 
            // LED_test_EXP_max_txt
            // 
            this.LED_test_EXP_max_txt.Location = new System.Drawing.Point(173, 145);
            this.LED_test_EXP_max_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_EXP_max_txt.Name = "LED_test_EXP_max_txt";
            this.LED_test_EXP_max_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_EXP_max_txt.TabIndex = 75;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(116, 120);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(55, 12);
            this.label45.TabIndex = 74;
            this.label45.Text = "EXP initial";
            // 
            // LED_test_EXP_initial_txt
            // 
            this.LED_test_EXP_initial_txt.Location = new System.Drawing.Point(173, 117);
            this.LED_test_EXP_initial_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_EXP_initial_txt.Name = "LED_test_EXP_initial_txt";
            this.LED_test_EXP_initial_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_EXP_initial_txt.TabIndex = 73;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(15, 148);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(21, 12);
            this.label46.TabIndex = 72;
            this.label46.Text = "AG";
            // 
            // LED_test_AG_txt
            // 
            this.LED_test_AG_txt.Location = new System.Drawing.Point(39, 145);
            this.LED_test_AG_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_AG_txt.Name = "LED_test_AG_txt";
            this.LED_test_AG_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_AG_txt.TabIndex = 71;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(15, 120);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(21, 12);
            this.label47.TabIndex = 70;
            this.label47.Text = "DG";
            // 
            // LED_test_DG_txt
            // 
            this.LED_test_DG_txt.Location = new System.Drawing.Point(39, 117);
            this.LED_test_DG_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_DG_txt.Name = "LED_test_DG_txt";
            this.LED_test_DG_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_DG_txt.TabIndex = 69;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(102, 55);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(18, 12);
            this.label48.TabIndex = 68;
            this.label48.Text = "T2";
            // 
            // LED_test_T2_txt
            // 
            this.LED_test_T2_txt.Location = new System.Drawing.Point(124, 52);
            this.LED_test_T2_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_T2_txt.Name = "LED_test_T2_txt";
            this.LED_test_T2_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_T2_txt.TabIndex = 67;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(17, 55);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(18, 12);
            this.label49.TabIndex = 66;
            this.label49.Text = "T1";
            // 
            // LED_test_T1_txt
            // 
            this.LED_test_T1_txt.Location = new System.Drawing.Point(39, 52);
            this.LED_test_T1_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_T1_txt.Name = "LED_test_T1_txt";
            this.LED_test_T1_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_T1_txt.TabIndex = 65;
            // 
            // LED_test_wl_txt
            // 
            this.LED_test_wl_txt.Location = new System.Drawing.Point(414, 344);
            this.LED_test_wl_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_wl_txt.Name = "LED_test_wl_txt";
            this.LED_test_wl_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_wl_txt.TabIndex = 62;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(357, 347);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(53, 12);
            this.label51.TabIndex = 61;
            this.label51.Text = "指定波長";
            // 
            // LED_test_a3_txt
            // 
            this.LED_test_a3_txt.Location = new System.Drawing.Point(306, 211);
            this.LED_test_a3_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_a3_txt.Name = "LED_test_a3_txt";
            this.LED_test_a3_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_a3_txt.TabIndex = 60;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(287, 213);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(16, 12);
            this.label52.TabIndex = 59;
            this.label52.Text = "a3";
            // 
            // LED_test_a2_txt
            // 
            this.LED_test_a2_txt.Location = new System.Drawing.Point(216, 211);
            this.LED_test_a2_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_a2_txt.Name = "LED_test_a2_txt";
            this.LED_test_a2_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_a2_txt.TabIndex = 58;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(197, 213);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(16, 12);
            this.label53.TabIndex = 57;
            this.label53.Text = "a2";
            // 
            // LED_test_a1_txt
            // 
            this.LED_test_a1_txt.Location = new System.Drawing.Point(125, 211);
            this.LED_test_a1_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_a1_txt.Name = "LED_test_a1_txt";
            this.LED_test_a1_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_a1_txt.TabIndex = 56;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(106, 213);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(16, 12);
            this.label54.TabIndex = 55;
            this.label54.Text = "a1";
            // 
            // LED_test_a0_txt
            // 
            this.LED_test_a0_txt.Location = new System.Drawing.Point(39, 211);
            this.LED_test_a0_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_a0_txt.Name = "LED_test_a0_txt";
            this.LED_test_a0_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_a0_txt.TabIndex = 54;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(20, 214);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(16, 12);
            this.label55.TabIndex = 53;
            this.label55.Text = "a0";
            // 
            // LED_test_interval_time_txt
            // 
            this.LED_test_interval_time_txt.Location = new System.Drawing.Point(188, 344);
            this.LED_test_interval_time_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_interval_time_txt.Name = "LED_test_interval_time_txt";
            this.LED_test_interval_time_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_interval_time_txt.TabIndex = 52;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(131, 347);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(53, 12);
            this.label56.TabIndex = 51;
            this.label56.Text = "間隔時間";
            // 
            // LED_test_total_times_txt
            // 
            this.LED_test_total_times_txt.Location = new System.Drawing.Point(75, 344);
            this.LED_test_total_times_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LED_test_total_times_txt.Name = "LED_test_total_times_txt";
            this.LED_test_total_times_txt.Size = new System.Drawing.Size(47, 22);
            this.LED_test_total_times_txt.TabIndex = 48;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(18, 347);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(53, 12);
            this.label57.TabIndex = 47;
            this.label57.Text = "測試時間";
            // 
            // A_LED_chart
            // 
            chartArea3.Name = "ChartArea1";
            this.A_LED_chart.ChartAreas.Add(chartArea3);
            legend3.Enabled = false;
            legend3.Name = "Legend1";
            this.A_LED_chart.Legends.Add(legend3);
            this.A_LED_chart.Location = new System.Drawing.Point(497, 3);
            this.A_LED_chart.Name = "A_LED_chart";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.IsVisibleInLegend = false;
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.A_LED_chart.Series.Add(series3);
            this.A_LED_chart.Size = new System.Drawing.Size(541, 265);
            this.A_LED_chart.TabIndex = 53;
            this.A_LED_chart.Text = "A_LED_chart";
            // 
            // btnLED_Test_Stop
            // 
            this.btnLED_Test_Stop.Enabled = false;
            this.btnLED_Test_Stop.Location = new System.Drawing.Point(406, 407);
            this.btnLED_Test_Stop.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLED_Test_Stop.Name = "btnLED_Test_Stop";
            this.btnLED_Test_Stop.Size = new System.Drawing.Size(79, 38);
            this.btnLED_Test_Stop.TabIndex = 47;
            this.btnLED_Test_Stop.Text = "停止";
            this.btnLED_Test_Stop.UseVisualStyleBackColor = true;
            // 
            // btnLED_Test_Start
            // 
            this.btnLED_Test_Start.Location = new System.Drawing.Point(323, 407);
            this.btnLED_Test_Start.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLED_Test_Start.Name = "btnLED_Test_Start";
            this.btnLED_Test_Start.Size = new System.Drawing.Size(79, 38);
            this.btnLED_Test_Start.TabIndex = 46;
            this.btnLED_Test_Start.Text = "開始測試";
            this.btnLED_Test_Start.UseVisualStyleBackColor = true;
            this.btnLED_Test_Start.Click += new System.EventHandler(this.btnLED_Test_Start_Click);
            // 
            // SP_test_page
            // 
            this.SP_test_page.Controls.Add(this.line_num_txt);
            this.SP_test_page.Controls.Add(this.label65);
            this.SP_test_page.Controls.Add(this.panel1);
            this.SP_test_page.Controls.Add(this.reflect_sp_chart);
            this.SP_test_page.Controls.Add(this.distance_sp_chart);
            this.SP_test_page.Controls.Add(this.point_sp_chart);
            this.SP_test_page.Controls.Add(this.dark_sp_chart);
            this.SP_test_page.Controls.Add(this.groupBox1);
            this.SP_test_page.Controls.Add(this.btnSpectrum_Test_Stop);
            this.SP_test_page.Controls.Add(this.btnSpectrum_Test_Start);
            this.SP_test_page.Location = new System.Drawing.Point(4, 22);
            this.SP_test_page.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_page.Name = "SP_test_page";
            this.SP_test_page.Size = new System.Drawing.Size(1041, 546);
            this.SP_test_page.TabIndex = 6;
            this.SP_test_page.Text = "光譜測試";
            this.SP_test_page.UseVisualStyleBackColor = true;
            // 
            // line_num_txt
            // 
            this.line_num_txt.Location = new System.Drawing.Point(65, 455);
            this.line_num_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.line_num_txt.Name = "line_num_txt";
            this.line_num_txt.Size = new System.Drawing.Size(54, 22);
            this.line_num_txt.TabIndex = 57;
            this.line_num_txt.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyUp);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(22, 458);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(41, 12);
            this.label65.TabIndex = 56;
            this.label65.Text = "線數目";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(124, 455);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 90);
            this.panel1.TabIndex = 55;
            // 
            // reflect_sp_chart
            // 
            chartArea4.Name = "ChartArea1";
            this.reflect_sp_chart.ChartAreas.Add(chartArea4);
            legend4.Enabled = false;
            legend4.Name = "Legend1";
            this.reflect_sp_chart.Legends.Add(legend4);
            this.reflect_sp_chart.Location = new System.Drawing.Point(494, 411);
            this.reflect_sp_chart.Name = "reflect_sp_chart";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.IsVisibleInLegend = false;
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.reflect_sp_chart.Series.Add(series4);
            this.reflect_sp_chart.Size = new System.Drawing.Size(541, 130);
            this.reflect_sp_chart.TabIndex = 54;
            this.reflect_sp_chart.Text = "reflect_sp_chart";
            // 
            // distance_sp_chart
            // 
            chartArea5.Name = "ChartArea1";
            this.distance_sp_chart.ChartAreas.Add(chartArea5);
            legend5.Enabled = false;
            legend5.Name = "Legend1";
            this.distance_sp_chart.Legends.Add(legend5);
            this.distance_sp_chart.Location = new System.Drawing.Point(494, 275);
            this.distance_sp_chart.Name = "distance_sp_chart";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series5.IsVisibleInLegend = false;
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.distance_sp_chart.Series.Add(series5);
            this.distance_sp_chart.Size = new System.Drawing.Size(541, 130);
            this.distance_sp_chart.TabIndex = 53;
            this.distance_sp_chart.Text = "distance_sp_chart";
            // 
            // point_sp_chart
            // 
            chartArea6.Name = "ChartArea1";
            this.point_sp_chart.ChartAreas.Add(chartArea6);
            legend6.Enabled = false;
            legend6.Name = "Legend1";
            this.point_sp_chart.Legends.Add(legend6);
            this.point_sp_chart.Location = new System.Drawing.Point(494, 139);
            this.point_sp_chart.Name = "point_sp_chart";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.IsVisibleInLegend = false;
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.point_sp_chart.Series.Add(series6);
            this.point_sp_chart.Size = new System.Drawing.Size(541, 130);
            this.point_sp_chart.TabIndex = 52;
            this.point_sp_chart.Text = "point_sp_chart";
            // 
            // dark_sp_chart
            // 
            chartArea7.Name = "ChartArea1";
            this.dark_sp_chart.ChartAreas.Add(chartArea7);
            legend7.Enabled = false;
            legend7.Name = "Legend1";
            this.dark_sp_chart.Legends.Add(legend7);
            this.dark_sp_chart.Location = new System.Drawing.Point(494, 3);
            this.dark_sp_chart.Name = "dark_sp_chart";
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series7.IsVisibleInLegend = false;
            series7.Legend = "Legend1";
            series7.Name = "Series1";
            this.dark_sp_chart.Series.Add(series7);
            this.dark_sp_chart.Size = new System.Drawing.Size(541, 130);
            this.dark_sp_chart.TabIndex = 51;
            this.dark_sp_chart.Text = "dark_sp_chart";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.baseline_end_txt);
            this.groupBox1.Controls.Add(this.label66);
            this.groupBox1.Controls.Add(this.baseline_start_txt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.SP_point_distance_txt);
            this.groupBox1.Controls.Add(this.label64);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.SP_test_roi_lc_txt);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.SP_test_roi_vo_txt);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.SP_test_roi_hc_txt);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.SP_test_roi_ho_txt);
            this.groupBox1.Controls.Add(this.label58);
            this.groupBox1.Controls.Add(this.SP_test_CAL_RUN_cycle_txt);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.SP_test_step_distance_txt);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.SP_test_x1_txt);
            this.groupBox1.Controls.Add(this.SP_test_Xsc_txt);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.SP_test_I_thr_txt);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.SP_test_I_max_txt);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.SP_test_EXP_max_txt);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.SP_test_EXP_initial_txt);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.SP_test_AG_txt);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.SP_test_DG_txt);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.SP_test_T2_txt);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.SP_test_T1_txt);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.SP_test_Xts_txt);
            this.groupBox1.Controls.Add(this.SP_test_wl_txt);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.SP_test_a3_txt);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.SP_test_a2_txt);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.SP_test_a1_txt);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.SP_test_a0_txt);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.SP_test_point_distance_steps_txt);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.SP_test_total_point_txt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.SP_test_xAS_txt);
            this.groupBox1.Location = new System.Drawing.Point(7, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(481, 439);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "光譜測試";
            // 
            // SP_point_distance_txt
            // 
            this.SP_point_distance_txt.Location = new System.Drawing.Point(360, 368);
            this.SP_point_distance_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_point_distance_txt.Name = "SP_point_distance_txt";
            this.SP_point_distance_txt.ReadOnly = true;
            this.SP_point_distance_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_point_distance_txt.TabIndex = 104;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(327, 371);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(29, 12);
            this.label64.TabIndex = 103;
            this.label64.Text = "間距";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label37.Location = new System.Drawing.Point(14, 285);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(28, 12);
            this.label37.TabIndex = 102;
            this.label37.Text = "ROI";
            // 
            // SP_test_roi_lc_txt
            // 
            this.SP_test_roi_lc_txt.Location = new System.Drawing.Point(361, 307);
            this.SP_test_roi_lc_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_roi_lc_txt.Name = "SP_test_roi_lc_txt";
            this.SP_test_roi_lc_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_roi_lc_txt.TabIndex = 101;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(325, 310);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(32, 12);
            this.label40.TabIndex = 100;
            this.label40.Text = "roi_lc";
            // 
            // SP_test_roi_vo_txt
            // 
            this.SP_test_roi_vo_txt.Location = new System.Drawing.Point(263, 307);
            this.SP_test_roi_vo_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_roi_vo_txt.Name = "SP_test_roi_vo_txt";
            this.SP_test_roi_vo_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_roi_vo_txt.TabIndex = 99;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(223, 310);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(36, 12);
            this.label41.TabIndex = 98;
            this.label41.Text = "roi_vo";
            // 
            // SP_test_roi_hc_txt
            // 
            this.SP_test_roi_hc_txt.Location = new System.Drawing.Point(162, 307);
            this.SP_test_roi_hc_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_roi_hc_txt.Name = "SP_test_roi_hc_txt";
            this.SP_test_roi_hc_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_roi_hc_txt.TabIndex = 97;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(122, 310);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(35, 12);
            this.label50.TabIndex = 96;
            this.label50.Text = "roi_hc";
            // 
            // SP_test_roi_ho_txt
            // 
            this.SP_test_roi_ho_txt.Location = new System.Drawing.Point(61, 307);
            this.SP_test_roi_ho_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_roi_ho_txt.Name = "SP_test_roi_ho_txt";
            this.SP_test_roi_ho_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_roi_ho_txt.TabIndex = 95;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(20, 310);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(36, 12);
            this.label58.TabIndex = 94;
            this.label58.Text = "roi_ho";
            // 
            // SP_test_CAL_RUN_cycle_txt
            // 
            this.SP_test_CAL_RUN_cycle_txt.Location = new System.Drawing.Point(191, 397);
            this.SP_test_CAL_RUN_cycle_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_CAL_RUN_cycle_txt.Name = "SP_test_CAL_RUN_cycle_txt";
            this.SP_test_CAL_RUN_cycle_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_CAL_RUN_cycle_txt.TabIndex = 93;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(134, 399);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 12);
            this.label32.TabIndex = 92;
            this.label32.Text = "測試次數";
            // 
            // SP_test_step_distance_txt
            // 
            this.SP_test_step_distance_txt.Location = new System.Drawing.Point(267, 368);
            this.SP_test_step_distance_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_step_distance_txt.Name = "SP_test_step_distance_txt";
            this.SP_test_step_distance_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_step_distance_txt.TabIndex = 91;
            this.SP_test_step_distance_txt.TextChanged += new System.EventHandler(this.SP_test_step_distance_txt_TextChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(234, 371);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 12);
            this.label31.TabIndex = 90;
            this.label31.Text = "步長";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label30.Location = new System.Drawing.Point(14, 346);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(57, 12);
            this.label30.TabIndex = 89;
            this.label30.Text = "檢測參數";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label29.Location = new System.Drawing.Point(14, 228);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(83, 12);
            this.label29.TabIndex = 88;
            this.label29.Text = "波長校正係數";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label28.Location = new System.Drawing.Point(14, 169);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(83, 12);
            this.label28.TabIndex = 87;
            this.label28.Text = "馬達移動參數";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label27.Location = new System.Drawing.Point(14, 82);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(102, 12);
            this.label27.TabIndex = 86;
            this.label27.Text = "Auto-scaling參數";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label26.Location = new System.Drawing.Point(14, 25);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(108, 12);
            this.label26.TabIndex = 85;
            this.label26.Text = "LED等待時間參數";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(286, 194);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 12);
            this.label22.TabIndex = 84;
            this.label22.Text = "x1";
            // 
            // SP_test_x1_txt
            // 
            this.SP_test_x1_txt.Location = new System.Drawing.Point(306, 192);
            this.SP_test_x1_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_x1_txt.Name = "SP_test_x1_txt";
            this.SP_test_x1_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_x1_txt.TabIndex = 83;
            // 
            // SP_test_Xsc_txt
            // 
            this.SP_test_Xsc_txt.Location = new System.Drawing.Point(39, 192);
            this.SP_test_Xsc_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_Xsc_txt.Name = "SP_test_Xsc_txt";
            this.SP_test_Xsc_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_Xsc_txt.TabIndex = 82;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(14, 194);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(22, 12);
            this.label21.TabIndex = 81;
            this.label21.Text = "Xsc";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(260, 137);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(25, 12);
            this.label18.TabIndex = 80;
            this.label18.Text = "I thr";
            // 
            // SP_test_I_thr_txt
            // 
            this.SP_test_I_thr_txt.Location = new System.Drawing.Point(288, 134);
            this.SP_test_I_thr_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_I_thr_txt.Name = "SP_test_I_thr_txt";
            this.SP_test_I_thr_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_I_thr_txt.TabIndex = 79;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(254, 109);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 12);
            this.label19.TabIndex = 78;
            this.label19.Text = "I max";
            // 
            // SP_test_I_max_txt
            // 
            this.SP_test_I_max_txt.Location = new System.Drawing.Point(288, 106);
            this.SP_test_I_max_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_I_max_txt.Name = "SP_test_I_max_txt";
            this.SP_test_I_max_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_I_max_txt.TabIndex = 77;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(123, 137);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 12);
            this.label16.TabIndex = 76;
            this.label16.Text = "EXP max";
            // 
            // SP_test_EXP_max_txt
            // 
            this.SP_test_EXP_max_txt.Location = new System.Drawing.Point(173, 134);
            this.SP_test_EXP_max_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_EXP_max_txt.Name = "SP_test_EXP_max_txt";
            this.SP_test_EXP_max_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_EXP_max_txt.TabIndex = 75;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(116, 109);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 12);
            this.label17.TabIndex = 74;
            this.label17.Text = "EXP initial";
            // 
            // SP_test_EXP_initial_txt
            // 
            this.SP_test_EXP_initial_txt.Location = new System.Drawing.Point(173, 106);
            this.SP_test_EXP_initial_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_EXP_initial_txt.Name = "SP_test_EXP_initial_txt";
            this.SP_test_EXP_initial_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_EXP_initial_txt.TabIndex = 73;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 137);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(21, 12);
            this.label14.TabIndex = 72;
            this.label14.Text = "AG";
            // 
            // SP_test_AG_txt
            // 
            this.SP_test_AG_txt.Location = new System.Drawing.Point(39, 134);
            this.SP_test_AG_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_AG_txt.Name = "SP_test_AG_txt";
            this.SP_test_AG_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_AG_txt.TabIndex = 71;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 109);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 12);
            this.label15.TabIndex = 70;
            this.label15.Text = "DG";
            // 
            // SP_test_DG_txt
            // 
            this.SP_test_DG_txt.Location = new System.Drawing.Point(39, 106);
            this.SP_test_DG_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_DG_txt.Name = "SP_test_DG_txt";
            this.SP_test_DG_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_DG_txt.TabIndex = 69;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(102, 51);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 12);
            this.label12.TabIndex = 68;
            this.label12.Text = "T2";
            // 
            // SP_test_T2_txt
            // 
            this.SP_test_T2_txt.Location = new System.Drawing.Point(124, 48);
            this.SP_test_T2_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_T2_txt.Name = "SP_test_T2_txt";
            this.SP_test_T2_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_T2_txt.TabIndex = 67;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(17, 51);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 12);
            this.label13.TabIndex = 66;
            this.label13.Text = "T1";
            // 
            // SP_test_T1_txt
            // 
            this.SP_test_T1_txt.Location = new System.Drawing.Point(39, 48);
            this.SP_test_T1_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_T1_txt.Name = "SP_test_T1_txt";
            this.SP_test_T1_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_T1_txt.TabIndex = 65;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(192, 194);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 12);
            this.label11.TabIndex = 64;
            this.label11.Text = "Xts";
            // 
            // SP_test_Xts_txt
            // 
            this.SP_test_Xts_txt.Location = new System.Drawing.Point(216, 192);
            this.SP_test_Xts_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_Xts_txt.Name = "SP_test_Xts_txt";
            this.SP_test_Xts_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_Xts_txt.TabIndex = 63;
            // 
            // SP_test_wl_txt
            // 
            this.SP_test_wl_txt.Location = new System.Drawing.Point(72, 398);
            this.SP_test_wl_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_wl_txt.Name = "SP_test_wl_txt";
            this.SP_test_wl_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_wl_txt.TabIndex = 62;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 399);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 61;
            this.label10.Text = "指定波長";
            // 
            // SP_test_a3_txt
            // 
            this.SP_test_a3_txt.Location = new System.Drawing.Point(306, 250);
            this.SP_test_a3_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_a3_txt.Name = "SP_test_a3_txt";
            this.SP_test_a3_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_a3_txt.TabIndex = 60;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(287, 253);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 12);
            this.label9.TabIndex = 59;
            this.label9.Text = "a3";
            // 
            // SP_test_a2_txt
            // 
            this.SP_test_a2_txt.Location = new System.Drawing.Point(216, 250);
            this.SP_test_a2_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_a2_txt.Name = "SP_test_a2_txt";
            this.SP_test_a2_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_a2_txt.TabIndex = 58;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 253);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 12);
            this.label8.TabIndex = 57;
            this.label8.Text = "a2";
            // 
            // SP_test_a1_txt
            // 
            this.SP_test_a1_txt.Location = new System.Drawing.Point(125, 250);
            this.SP_test_a1_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_a1_txt.Name = "SP_test_a1_txt";
            this.SP_test_a1_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_a1_txt.TabIndex = 56;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(106, 253);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 12);
            this.label7.TabIndex = 55;
            this.label7.Text = "a1";
            // 
            // SP_test_a0_txt
            // 
            this.SP_test_a0_txt.Location = new System.Drawing.Point(39, 250);
            this.SP_test_a0_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_a0_txt.Name = "SP_test_a0_txt";
            this.SP_test_a0_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_a0_txt.TabIndex = 54;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 254);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 12);
            this.label6.TabIndex = 53;
            this.label6.Text = "a0";
            // 
            // SP_test_point_distance_steps_txt
            // 
            this.SP_test_point_distance_steps_txt.Location = new System.Drawing.Point(176, 368);
            this.SP_test_point_distance_steps_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_point_distance_steps_txt.Name = "SP_test_point_distance_steps_txt";
            this.SP_test_point_distance_steps_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_point_distance_steps_txt.TabIndex = 52;
            this.SP_test_point_distance_steps_txt.TextChanged += new System.EventHandler(this.SP_test_point_distance_steps_txt_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(119, 371);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 51;
            this.label5.Text = "間距步數";
            // 
            // SP_test_total_point_txt
            // 
            this.SP_test_total_point_txt.Location = new System.Drawing.Point(62, 368);
            this.SP_test_total_point_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_total_point_txt.Name = "SP_test_total_point_txt";
            this.SP_test_total_point_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_total_point_txt.TabIndex = 48;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 371);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 47;
            this.label3.Text = "總點數";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 194);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 12);
            this.label2.TabIndex = 46;
            this.label2.Text = "xAS";
            // 
            // SP_test_xAS_txt
            // 
            this.SP_test_xAS_txt.Location = new System.Drawing.Point(125, 192);
            this.SP_test_xAS_txt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SP_test_xAS_txt.Name = "SP_test_xAS_txt";
            this.SP_test_xAS_txt.Size = new System.Drawing.Size(47, 22);
            this.SP_test_xAS_txt.TabIndex = 45;
            // 
            // btnSpectrum_Test_Stop
            // 
            this.btnSpectrum_Test_Stop.Enabled = false;
            this.btnSpectrum_Test_Stop.Location = new System.Drawing.Point(410, 466);
            this.btnSpectrum_Test_Stop.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSpectrum_Test_Stop.Name = "btnSpectrum_Test_Stop";
            this.btnSpectrum_Test_Stop.Size = new System.Drawing.Size(79, 38);
            this.btnSpectrum_Test_Stop.TabIndex = 22;
            this.btnSpectrum_Test_Stop.Text = "停止";
            this.btnSpectrum_Test_Stop.UseVisualStyleBackColor = true;
            this.btnSpectrum_Test_Stop.Click += new System.EventHandler(this.btnSpectrum_Test_Stop_Click);
            // 
            // btnSpectrum_Test_Start
            // 
            this.btnSpectrum_Test_Start.Location = new System.Drawing.Point(328, 466);
            this.btnSpectrum_Test_Start.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSpectrum_Test_Start.Name = "btnSpectrum_Test_Start";
            this.btnSpectrum_Test_Start.Size = new System.Drawing.Size(79, 38);
            this.btnSpectrum_Test_Start.TabIndex = 21;
            this.btnSpectrum_Test_Start.Text = "開始測試";
            this.btnSpectrum_Test_Start.UseVisualStyleBackColor = true;
            this.btnSpectrum_Test_Start.Click += new System.EventHandler(this.btnSpectrum_Test_Start_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackgroundImage = global::Spectrum_Test.Properties.Resources.refresh;
            this.btnRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefresh.Location = new System.Drawing.Point(330, 4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(36, 36);
            this.btnRefresh.TabIndex = 10;
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // cboPort
            // 
            this.cboPort.FormattingEnabled = true;
            this.cboPort.Location = new System.Drawing.Point(111, 12);
            this.cboPort.Name = "cboPort";
            this.cboPort.Size = new System.Drawing.Size(137, 20);
            this.cboPort.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "COM Port";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(254, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(70, 21);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "Disconnect";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Visible = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(254, 12);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(70, 21);
            this.btnOpen.TabIndex = 11;
            this.btnOpen.Text = "Connect";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(840, 16);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(32, 12);
            this.label20.TabIndex = 13;
            this.label20.Text = "狀態:";
            // 
            // status_lb
            // 
            this.status_lb.AutoSize = true;
            this.status_lb.Location = new System.Drawing.Point(881, 16);
            this.status_lb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.status_lb.Name = "status_lb";
            this.status_lb.Size = new System.Drawing.Size(0, 12);
            this.status_lb.TabIndex = 14;
            // 
            // txtAPI
            // 
            this.txtAPI.Location = new System.Drawing.Point(470, 31);
            this.txtAPI.Name = "txtAPI";
            this.txtAPI.Size = new System.Drawing.Size(100, 22);
            this.txtAPI.TabIndex = 15;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(468, 16);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(221, 12);
            this.label33.TabIndex = 16;
            this.label33.Text = "輸入機台編號或晶片編號，取得機台參數";
            // 
            // btnApi
            // 
            this.btnApi.Location = new System.Drawing.Point(576, 30);
            this.btnApi.Name = "btnApi";
            this.btnApi.Size = new System.Drawing.Size(75, 23);
            this.btnApi.TabIndex = 17;
            this.btnApi.Text = "確定";
            this.btnApi.UseVisualStyleBackColor = true;
            this.btnApi.Click += new System.EventHandler(this.btnApi_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chart5);
            this.tabPage1.Controls.Add(this.chart4);
            this.tabPage1.Controls.Add(this.chart3);
            this.tabPage1.Controls.Add(this.chart2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1041, 546);
            this.tabPage1.TabIndex = 10;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // chart2
            // 
            chartArea11.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea11);
            legend11.Enabled = false;
            legend11.Name = "Legend1";
            this.chart2.Legends.Add(legend11);
            this.chart2.Location = new System.Drawing.Point(207, 3);
            this.chart2.Name = "chart2";
            series11.ChartArea = "ChartArea1";
            series11.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series11.IsVisibleInLegend = false;
            series11.Legend = "Legend1";
            series11.Name = "Series1";
            this.chart2.Series.Add(series11);
            this.chart2.Size = new System.Drawing.Size(541, 130);
            this.chart2.TabIndex = 55;
            this.chart2.Text = "chart2";
            // 
            // chart3
            // 
            chartArea10.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea10);
            legend10.Enabled = false;
            legend10.Name = "Legend1";
            this.chart3.Legends.Add(legend10);
            this.chart3.Location = new System.Drawing.Point(207, 139);
            this.chart3.Name = "chart3";
            series10.ChartArea = "ChartArea1";
            series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series10.IsVisibleInLegend = false;
            series10.Legend = "Legend1";
            series10.Name = "Series1";
            this.chart3.Series.Add(series10);
            this.chart3.Size = new System.Drawing.Size(541, 130);
            this.chart3.TabIndex = 56;
            this.chart3.Text = "chart3";
            // 
            // chart4
            // 
            chartArea9.Name = "ChartArea1";
            this.chart4.ChartAreas.Add(chartArea9);
            legend9.Enabled = false;
            legend9.Name = "Legend1";
            this.chart4.Legends.Add(legend9);
            this.chart4.Location = new System.Drawing.Point(207, 275);
            this.chart4.Name = "chart4";
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series9.IsVisibleInLegend = false;
            series9.Legend = "Legend1";
            series9.Name = "Series1";
            this.chart4.Series.Add(series9);
            this.chart4.Size = new System.Drawing.Size(541, 130);
            this.chart4.TabIndex = 57;
            this.chart4.Text = "chart4";
            // 
            // chart5
            // 
            chartArea8.Name = "ChartArea1";
            this.chart5.ChartAreas.Add(chartArea8);
            legend8.Enabled = false;
            legend8.Name = "Legend1";
            this.chart5.Legends.Add(legend8);
            this.chart5.Location = new System.Drawing.Point(207, 411);
            this.chart5.Name = "chart5";
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series8.IsVisibleInLegend = false;
            series8.Legend = "Legend1";
            series8.Name = "Series1";
            this.chart5.Series.Add(series8);
            this.chart5.Size = new System.Drawing.Size(541, 130);
            this.chart5.TabIndex = 58;
            this.chart5.Text = "chart5";
            // 
            // baseline_start_txt
            // 
            this.baseline_start_txt.Location = new System.Drawing.Point(328, 411);
            this.baseline_start_txt.Margin = new System.Windows.Forms.Padding(2);
            this.baseline_start_txt.Name = "baseline_start_txt";
            this.baseline_start_txt.Size = new System.Drawing.Size(47, 22);
            this.baseline_start_txt.TabIndex = 106;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(325, 397);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 12);
            this.label4.TabIndex = 105;
            this.label4.Text = "baseline_start";
            // 
            // baseline_end_txt
            // 
            this.baseline_end_txt.Location = new System.Drawing.Point(419, 410);
            this.baseline_end_txt.Margin = new System.Windows.Forms.Padding(2);
            this.baseline_end_txt.Name = "baseline_end_txt";
            this.baseline_end_txt.Size = new System.Drawing.Size(47, 22);
            this.baseline_end_txt.TabIndex = 108;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(408, 397);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(65, 12);
            this.label66.TabIndex = 107;
            this.label66.Text = "baseline_end";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1054, 620);
            this.Controls.Add(this.btnApi);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.txtAPI);
            this.Controls.Add(this.status_lb);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.cboPort);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRefresh);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.Command_page.ResumeLayout(false);
            this.Command_page.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.Motor_test_page.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.LED_test_page.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.B_LED_chart)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.A_LED_chart)).EndInit();
            this.SP_test_page.ResumeLayout(false);
            this.SP_test_page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reflect_sp_chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.distance_sp_chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.point_sp_chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dark_sp_chart)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.ComboBox cboPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClose;
        private System.IO.Ports.SerialPort serialPort;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.TabPage Command_page;
        private System.Windows.Forms.Button btnCommand;
        private System.Windows.Forms.TextBox txtCommand;
        private System.Windows.Forms.Button btnCAL;
        private System.Windows.Forms.Button btnAGN;
        private System.Windows.Forms.Button btnAGN1X;
        private System.Windows.Forms.Button btnAGN2X;
        private System.Windows.Forms.Button btnELC;
        private System.Windows.Forms.Button btnGNV128;
        private System.Windows.Forms.Button btnGNV;
        private System.Windows.Forms.Button btnELC1000;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnROI;
        private System.Windows.Forms.TabPage SP_test_page;
        private System.Windows.Forms.Button btnSpectrum_Test_Start;
        private System.Windows.Forms.Button btnSpectrum_Test_Stop;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label status_lb;
        private System.Windows.Forms.TabPage LED_test_page;
        private System.Windows.Forms.TabPage Motor_test_page;
        private System.Windows.Forms.Button btnMotor_Test;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txt_motor_test_round;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox SP_test_x1_txt;
        private System.Windows.Forms.TextBox SP_test_Xsc_txt;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox SP_test_I_thr_txt;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox SP_test_I_max_txt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox SP_test_EXP_max_txt;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox SP_test_EXP_initial_txt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox SP_test_AG_txt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox SP_test_DG_txt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox SP_test_T2_txt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox SP_test_T1_txt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox SP_test_Xts_txt;
        private System.Windows.Forms.TextBox SP_test_wl_txt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox SP_test_a3_txt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox SP_test_a2_txt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox SP_test_a1_txt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox SP_test_a0_txt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox SP_test_point_distance_steps_txt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox SP_test_total_point_txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox SP_test_xAS_txt;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart dark_sp_chart;
        private System.Windows.Forms.TextBox SP_test_step_distance_txt;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.DataVisualization.Charting.Chart reflect_sp_chart;
        private System.Windows.Forms.DataVisualization.Charting.Chart distance_sp_chart;
        private System.Windows.Forms.DataVisualization.Charting.Chart point_sp_chart;
        private System.Windows.Forms.TextBox SP_test_CAL_RUN_cycle_txt;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.DataVisualization.Charting.Chart B_LED_chart;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox LED_test_RUN_cycle_txt;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox LED_test_I_thr_txt;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox LED_test_I_max_txt;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox LED_test_EXP_max_txt;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox LED_test_EXP_initial_txt;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox LED_test_AG_txt;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox LED_test_DG_txt;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox LED_test_T2_txt;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox LED_test_T1_txt;
        private System.Windows.Forms.TextBox LED_test_wl_txt;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox LED_test_a3_txt;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox LED_test_a2_txt;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox LED_test_a1_txt;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox LED_test_a0_txt;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox LED_test_interval_time_txt;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox LED_test_total_times_txt;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.DataVisualization.Charting.Chart A_LED_chart;
        private System.Windows.Forms.Button btnLED_Test_Stop;
        private System.Windows.Forms.Button btnLED_Test_Start;
        private System.Windows.Forms.TextBox txtAPI;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button btnApi;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox SP_test_roi_lc_txt;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox SP_test_roi_vo_txt;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox SP_test_roi_hc_txt;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox SP_test_roi_ho_txt;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox LED_test_roi_lc_txt;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox LED_test_roi_vo_txt;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox LED_test_roi_hc_txt;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox LED_test_roi_ho_txt;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TabPage BLE_test_page;
        private System.Windows.Forms.TextBox SP_point_distance_txt;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox line_num_txt;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.TextBox baseline_end_txt;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox baseline_start_txt;
        private System.Windows.Forms.Label label4;
    }
}

